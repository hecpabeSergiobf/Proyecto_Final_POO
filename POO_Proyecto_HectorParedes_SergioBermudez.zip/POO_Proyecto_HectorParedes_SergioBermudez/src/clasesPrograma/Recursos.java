

/*
 * 	T�tulo: Recursos
 * 	Nombre: H�ctor Paredes Benavides
 * 	Descripci�n: Clase abstracta con la que representamos los recursos del programa
 */

package clasesPrograma;

public abstract class Recursos {
	
	public abstract String printDatos();
	
}
