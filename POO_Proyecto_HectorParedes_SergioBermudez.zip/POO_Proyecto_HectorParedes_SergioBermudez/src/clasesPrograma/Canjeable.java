

/*
 * 	T�tulo: Canjeable
 * 	Nombre: H�ctor Paredes Benavides
 * 	Descripci�n: Creamos una interfaz para los recursos canjeables del programa
 */

package clasesPrograma;

public interface Canjeable {

	public int canjea(int cantidadACanjear);
	
}
