

/*
 * 	T�tulo: Guardia
 * 	Nombre: H�ctor Paredes Benavides / Sergio Bermudez Fern�ndez
 * 	Descripci�n: Clase con la que trabajamos con los guardias
 */

package clasesPrograma;

public class Guardia extends Personas {

	/* Atributos */
	private int aptitud;
	private static int contGuardias=0;
	
	/* Constructores */
	public Guardia(String nombre, int aptitud) {
		
		super(nombre);
		this.aptitud = aptitud;
		contGuardias++;
		
	}
	
	/* M�todos Getters */
	public int getAptitud() {
		
		return aptitud;
		
	}
	
	public static int getcontGuardias() {

		
		return contGuardias;
		
	}
	
	//Asignacion de puesto
	public final void setPuesto(String puesto) {
		
		super.setPuesto(puesto);
		
	}
	
	/* M�todos P�blicos */
	public String printDatos() {
		
		
		return ("\n"+"Nombre: "+super.getNombre()+" Puesto: "+super.getPuesto() +"\nAptitud: "+aptitud+"\n");
		
		
	}
	
}
