//

/*

 * 	T�tulo: EscrituraFichero
 * 	Nombre: H�ctor Paredes Benavides / Sergio Bermudez Fern�ndez
 * 	Descripci�n: Clase con la que escribimos la asignacion final en el ficheros
 */

package entradaSalida;

import java.util.*;

import clasesPrograma.*;

import java.io.*;

public class EscrituraFichero {


	
	public static void escrituraEnFichero(ArrayList<Personas> finalPersonas,ArrayList<Recursos> finalRecursos) {
		

		
		try {
			
			//Abrimos un fileWritter para escribir en nuestro fichero
			FileWriter escritura=new FileWriter("src/ficheros/expedicion.txt");
			
			//Imprimimos con polimorfismo en el fihero las personas
			for(int indice=0;indice<finalPersonas.size();indice++) {
				//Imprimimos en el fichero todas las personas con sus datos que van a la expedicion
				escritura.write(finalPersonas.get(indice).printDatos());
				
			}
			
			//Imprimimos con polimorfismo en el fihero los recursos
			for(int indice=0;indice<finalRecursos.size();indice++) {
				//Escribimos en el fichero los recusrsos que llevamos a la expedicion
				escritura.write(finalRecursos.get(indice).printDatos());
				
			}
			
			
			escritura.close();
			
		}catch(IOException exc) {
			//En caso de que haya un error que nos diga que a pasado
			exc.getStackTrace();
			System.exit(1);
			
		}
		
	
		
		
	}
		
	
	
}
